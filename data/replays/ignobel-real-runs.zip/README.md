# ignobel real-research runs (swarm-viewer/v1)

Same layout as `data/replays/swarm-viewer-sample-runs.zip`: `runs/index.json` and one directory per run
with `manifest.json`, `timeline.json`, `events.ndjson`, `keyframes/` and `entities/`.

Each run also carries `artifacts/`:

| file | what |
|---|---|
| `trace.html` | the whole run as one page: conversations, research steps, boredom readings, studies |
| `scores.jsonl` | committee scores per study, `supported`, `traceable`, `preceded_by`, `candidate` |
| `events.jsonl` | the run's native event log with evidence checked under the current rules |
| `events.recorded.jsonl` | the event log exactly as the run wrote it |
| `research_log.jsonl` | every literature and dataset lookup |
| `prompts.jsonl` | every model call |
| `plots/*.svg` | one plot per study |

Nothing here is planted: every study ran on a public dataset (DOI, licence and sha256 are on each
experiment's `evidence.datasets`). The dataset files themselves are not included.

Study status: `replicated` = supported by real data and first to its finding (these are the
discoveries); `duplicate` = supported, but an earlier study reported the same values of the same
columns; `not_traceable` = replicated, but the reported values are not cells of the dataset it read;
`not_replicated`; `failed`.

Three of the four runs finished before the traceability and priority rules existed. For this export each
study's saved code was re-run on its saved dataset (no network) and checked under those rules;
`evidence.rechecked` marks this and `evidence.supported_when_run` keeps the original verdict where it
changed. Committee scores are the ones given at the time of the run.

To replay in the Lab Environment: `LAB_RECORDINGS_ZIP=/abs/path/ignobel-real-runs.zip npm run dev`.
